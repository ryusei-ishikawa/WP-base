<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.4/css/all.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300|Raleway&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
</head>
<body>
    <div id="site_wrap">
        <header id="hdr">
            <div id="hdr_inner">
                <div class="logo_waku">
                    <?php original_the_custom_logo(); ?><!--　ロゴ  -->
                    <?php bloginfo('description'); ?><!--　キャッチフレーズ  -->
                </div>
                <!--　PCメニュー　ここから  -->
                <nav class="pc_nav">
                    <div class="pc_navi-in">
                        <?php wp_nav_menu(
                        array (
                            'theme_location' => 'global',
                            'container' => false,
                            'fallback_cb' => false,
                            'items_wrap' => '<ul>%3$s</ul>',
                            )
                        ); ?>
                    </div>
                </nav>
                <!--　PCメニュー　ここまで  -->
                <!--　SPメニュー　ここから-->
                <nav id="navArea">
                    <div class="sp_nav">
                        <div class="inner">
                            <?php wp_nav_menu(
                            array (
                                'theme_location' => 'global',
                                'container' => false,
                                'fallback_cb' => false,
                                'items_wrap' => '<ul>%3$s</ul>',
                            )
                            ); ?>
                        </div>
                    </div>
                    <div class="toggle_btn">
                        <span class="bg_co_hb02"></span>
                        <span class="bg_co_hb02"></span>
                        <span class="bg_co_hb02"></span>
                    </div>
                    <div id="mask"></div>
                </nav>
                <!-- SPメニュー　ここまで -->
            </div>
        </header>