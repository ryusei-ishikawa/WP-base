<form id="form" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
    <input id="s-box" name="s" type="text" placeholder="サイト内検索"/>
    <button type="submit" id="s-btn-area"><div id="s-btn">検索</div></button>
</form>