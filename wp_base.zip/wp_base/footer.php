        <footer id="ftr">
            <small><a href="<?php echo home_url( '/' );?>">©︎<?php bloginfo( 'name' ); ?></a> </small>
        </footer>
    </div>
    <!-- 戻るボタン -->
    <div id="page_top"><a href="#"></a></div>
    <?php wp_footer(); ?>
</body>
</html>