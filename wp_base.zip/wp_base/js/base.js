// ハンバーガーメニュー
(function($) {
    var $nav   = $('#navArea');
    var $btn   = $('.toggle_btn');
    var $mask  = $('#mask');
    var open   = 'open'; // class
    // menu open close
    $btn.on( 'click', function() {
      if ( ! $nav.hasClass( open ) ) {
        $nav.addClass( open );
      } else {
        $nav.removeClass( open );
      }
    });
    // mask close
    $mask.on('click', function() {
      $nav.removeClass( open );
    });
  } )(jQuery);
  
//  戻るボタン
jQuery(function() {
    var pagetop = $('#page_top');   
    pagetop.hide();
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {  //100pxスクロールしたら表示
            pagetop.fadeIn();
        } else {
            pagetop.fadeOut();
        }
    });
  $('a[href^="#"]').click(function(){
    var time = 500;
    var href= $(this).attr("href");
    var target = $(href == "#" ? 'html' : href);
    var distance = target.offset().top;
    $("html, body").animate({scrollTop:distance}, time, "swing");
    return false;
  });
  });
  
  // ローディング
var $delayTime = 1000;

$(window).on('load', function(){
  var $loadingAnim = $('#loadingAnim'),
      $body = $('body');

    setTimeout( function(){
        
      $body.addClass('loaded');
  
      $loadingAnim.find('.loadingAnim_line').on('transitionend', function( e ){ 
        $(this).parent().remove(); }); }, $delayTime );
 });


//  ヘッダー途中から付いてくるように
$(function() {
  var headNav = $("header");
  //scrollだけだと読み込み時困るのでloadも追加
  $(window).on('load scroll', function () {
      //現在の位置が500px以上かつ、クラスfixedが付与されていない時
      if($(this).scrollTop() > 500 && headNav.hasClass('fixed') == false) {
          //headerの高さ分上に設定
          headNav.css({"top": '-100px'});
          //クラスfixedを付与
          headNav.addClass('fixed');
          //位置を0に設定し、アニメーションのスピードを指定
          headNav.animate({"top": 0},600);
      }
      //現在の位置が300px以下かつ、クラスfixedが付与されている時にfixedを外す
      else if($(this).scrollTop() < 300 && headNav.hasClass('fixed') == true){
          headNav.removeClass('fixed');
      }
  });
});