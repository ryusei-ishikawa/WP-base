<?php get_header(); ?>
        <div class="page_waku_ptn01">
            <main class="p_ptn_01">
                <!-- パンくずリスト -->
                <div class="pan_list"><?php custom_breadcrumb(); ?></div>
                <!-- コンテンツの中 -->
                <section>
                <?php if(have_posts()): while(have_posts()): the_post();?>
                <h1><?php the_title(); ?></h1>

                <?php the_content(); ?>
                    <div class="pages"><?php wp_link_pages(); ?></div>
                    <?php 
                            wp_link_pages( array(
                                'before'    => '<div class="pagebreak-links">',
                                'after'     => '</div>',
                                'pagelink'  => '<span class="page-number">%</span>',
                            ) ); 
                        ?>
                    <?php endwhile; endif; ?>
                </section>
            </main>
            <?php get_sidebar(); ?>
        </div>
<?php get_footer(); ?>

