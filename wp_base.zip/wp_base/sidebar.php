<aside class="sidebar">
    <!-- sidebar ウィジェット-->
    <?php if ( is_active_sidebar( 'sidebar' ) ) :
    dynamic_sidebar( 'sidebar' );
    else: ?>
    <?php endif; ?>
    <!-- /sidebar -->
</aside>