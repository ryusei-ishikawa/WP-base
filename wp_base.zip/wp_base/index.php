<?php get_header(); ?>
    <!-- ローディングアニメーション -->
    <div id="loadingAnim" class="loadingAnim">
        <i class="loadingAnim_line"></i>
    </div>



    

<?php get_footer(); ?>
    
